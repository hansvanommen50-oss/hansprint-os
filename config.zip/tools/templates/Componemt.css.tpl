.hds-{{kebab}} {

}