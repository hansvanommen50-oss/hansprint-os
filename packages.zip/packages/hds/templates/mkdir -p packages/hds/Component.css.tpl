.{{kebab}} {

}
