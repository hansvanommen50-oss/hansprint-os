export interface {{Component}}Props {

}